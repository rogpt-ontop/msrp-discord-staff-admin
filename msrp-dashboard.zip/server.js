const express = require("express");
const fs = require("fs");
const bodyParser = require("body-parser");
const cors = require("cors");
const app = express();
const PORT = 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(express.static("public"));

const DATA_FILE = "./data.json";

function loadData() {
    if (!fs.existsSync(DATA_FILE)) {
        fs.writeFileSync(DATA_FILE, JSON.stringify({}, null, 2));
    }
    const data = fs.readFileSync(DATA_FILE);
    return JSON.parse(data);
}

function saveData(data) {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

// Get all staff
app.get("/api/staff", (req, res) => {
    res.json(loadData());
});

// Add or update staff
app.post("/api/staff", (req, res) => {
    const { name, info } = req.body;
    const data = loadData();
    data[name] = info;
    saveData(data);
    res.json({ success: true });
});

// Delete staff
app.delete("/api/staff/:name", (req, res) => {
    const name = req.params.name;
    const data = loadData();
    delete data[name];
    saveData(data);
    res.json({ success: true });
});

app.listen(PORT, () => {
    console.log(`✅ MSRP Staff Dashboard running on http://localhost:${PORT}`);
});